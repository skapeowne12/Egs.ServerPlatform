﻿using Egs.Agent.Abstractions.Commands;
using Egs.Agent.Abstractions.Console;
using Egs.Agent.Abstractions.Status;

namespace Egs.Agent.Windows.Services;

public sealed class AgentWorker : BackgroundService
{
    private readonly ControlPlaneClient _controlPlaneClient;
    private readonly ILogger<AgentWorker> _logger;

    public AgentWorker(
        ControlPlaneClient controlPlaneClient,
        ILogger<AgentWorker> logger)
    {
        _controlPlaneClient = controlPlaneClient;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Agent worker started.");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var commands = await _controlPlaneClient.PollCommandsAsync(stoppingToken);

                foreach (var command in commands)
                {
                    await ProcessCommandAsync(command, stoppingToken);
                }
            }
            catch (HttpRequestException ex)
            {
                _logger.LogWarning("API not ready yet: {Message}", ex.Message);
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Agent polling loop failed.");
            }

            await Task.Delay(TimeSpan.FromSeconds(2), stoppingToken);
        }
    }

    private async Task ProcessCommandAsync(ServerCommandMessage command, CancellationToken ct)
    {
        _logger.LogInformation(
            "Processing command {CommandId} for server {ServerId}: {CommandType}",
            command.CommandId,
            command.ServerId,
            command.Type);

        await EmitLineAsync(command.ServerId, $"[{command.Type}] Command received.", ct);
        await Task.Delay(300, ct);

        await EmitLineAsync(command.ServerId, $"[{command.Type}] Validating runtime...", ct);
        await Task.Delay(300, ct);

        await EmitLineAsync(command.ServerId, $"[{command.Type}] Preparing server process...", ct);
        await Task.Delay(300, ct);

        string finalStatus = command.Type switch
        {
            ServerCommandType.Start => "Running",
            ServerCommandType.Stop => "Stopped",
            ServerCommandType.Restart => "Running",
            _ => "Unknown"
        };

        int? processId = finalStatus == "Running"
            ? Random.Shared.Next(1000, 99999)
            : null;

        await EmitLineAsync(command.ServerId, $"[{command.Type}] Final status: {finalStatus}", ct);

        await _controlPlaneClient.PostStatusAsync(
            new AgentServerUpdateMessage(
                command.ServerId,
                finalStatus,
                processId,
                null,
                DateTimeOffset.UtcNow),
            ct);

        _logger.LogInformation(
            "Completed command {CommandId} for server {ServerId}. Final status: {Status}",
            command.CommandId,
            command.ServerId,
            finalStatus);
    }

    private Task EmitLineAsync(Guid serverId, string line, CancellationToken ct) =>
        _controlPlaneClient.PostConsoleLineAsync(
            new ConsoleLineMessage(serverId, DateTimeOffset.UtcNow, line),
            ct);
}